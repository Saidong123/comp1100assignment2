{-# LANGUAGE OverloadedStrings #-}

module Main where

import CodeWorld
import TestPattern
import qualified Turtle as Turtle

data Mode
  = Triangle
  | Polygon Int
  | Comp1100
  | Koch Int

main :: IO ()
main = interactionOf Comp1100 unchanging handleEvent render

unchanging :: Double -> Mode -> Mode
unchanging _ mode = mode

handleEvent :: Event -> Mode -> Mode
handleEvent (KeyPress k) mode
  | k == "C" = Comp1100
  | k == "K" = Koch 3
  | k == "T" = Triangle
  | k == "P" = case mode of
      Polygon _ -> mode
      _ -> Polygon 5
  | k == "-" = case mode of
      Polygon n -> Polygon (max (pred n) 3)
      Koch n -> Koch (max (pred n) 0)
      _ -> mode
  | k == "=" = case mode of
      Polygon n -> Polygon (succ n)
      Koch n -> Koch (succ n)
      _ -> mode
handleEvent _ mode = mode

render :: Mode -> Picture
render mode = colored red picture & coordinatePlane
  where picture = Turtle.runTurtle
          (case mode of
             Triangle -> Turtle.triangle 6.5
             Polygon n -> Turtle.polygon n 3.0
             Comp1100 -> comp1100
             Koch n -> Turtle.koch n 10.0)
