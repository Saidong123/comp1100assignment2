module Turtle where

import CodeWorld hiding (polygon)

type Radians = Double

-- | The commands that we can send to our turtle.
data TurtleCommand
  = Forward Double -- ^ Drive forward the given number of units, and
                   -- draw a line.
  | Jump Double -- ^ Move forward the given number of units, but do
                -- not draw a line.
  | Turn Radians -- ^ Turn the turtle. Positive values are
                 -- anticlockwise; negative values are clockwise.
  deriving (Eq, Show)

-- Task 1: Drawing Shapes

triangle :: Double -> [TurtleCommand]
triangle = undefined -- TODO

polygon :: Int -> Double -> [TurtleCommand]
polygon = undefined -- TODO



-- Task 2: Interpreting Turtle Commands

runTurtle :: [TurtleCommand] -> Picture
runTurtle = undefined -- TODO



-- Task 3: Koch Snowflake

koch :: Int -> Double -> [TurtleCommand]
koch = undefined -- TODO
